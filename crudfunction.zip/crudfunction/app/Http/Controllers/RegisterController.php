<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class RegisterController extends Controller
{
    public function register(Request $request){
         $validated_data = $request->validate([
               'name'=>'required',
               'email'=>'required',
               'phone'=>'nullable',
               'dob'=>'required',
               'password'=>'required',
               'image'=>'required',
        ]);
        return $validated_data;
    }
}

<h3>Edit User Form</h3><br>
<form action="{{url('update/'.$user->id)}}" method="POST">
    <label for="">Name</label><input type="text" name="name" value="{{$user->name}}"><br>
    <label for="">Age</label><input type="text" name="age" value="{{$user->age}}"><br>
    <label for="">Phone</label><input type="text" name="phone" value="$user->phone}}"><br>
    <input type="submit" value="Update User">
    @csrf
</form>
<h3>User List</h3>
<style>
table, th, td{
        border: 1px solid black;
        border-collapse: collapse;
    }
</style>
<table>
    <thead>
        <th>ID</th>
        <th>Name</th>
        <th>Age</th>
        <th>Phone</th>
        <th>Edit</th>
        <th>Delete</th>
    </thead>
<tbody>
    @foreach($users as $user)
    <tr>
    <td>{{$user->id}}</td>
    <td>{{$user->name}}</td>
    <td>{{$user->age}}</td>
    <td>{{$user->phone}}</td>
    <td><a href="edit/{{$user->id}}">Edit</a></td>
    <td><a href="delete/{{$user->id}}">Delete</a></td>
    </tr>
    @endforeach
</tbody>
</table>

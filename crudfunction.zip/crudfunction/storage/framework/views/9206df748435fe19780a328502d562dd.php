<html>
    <head>
        <title>Sign Up</title>
    </head>
    <body>
        <div style="padding-left:200px">
        <h3>Register</h3>
        <?php if($errors->any()): ?>
            <ul>
                <?php echo implode('',$errors->all('<li>:message</li>')); ?>

            </ul>
        <?php endif; ?>
        <form enctype="multipart/form-data" method="POST" action="register">
            <label for="">Name <input type="text" name="name" id="" value="<?php echo e(old('name')); ?>"></label><br>
            <label for="">Email <input type="text" name="email" id="" value="<?php echo e(old('email')); ?>"></label><br>
            <label for="">Phone <input type="text" name="phone" id="" value="<?php echo e(old('phone')); ?>"></label><br>
            <label for="">DOB <input type="date" name="dob" id="" value="<?php echo e(old('dob')); ?>"></label><br>
            <label for="">Image <input type="file" name="image" id=""></label><br>
            <label for="">Password <input type="password" name="password" id=""></label><br>
            <label for="">Confirm Password <input type="password" name="password_confirmation" id=""></label><br>
            <input type="submit" value="register">
            <?php echo csrf_field(); ?>
        </form>
        </div>
    </body>
</html><?php /**PATH C:\crudfunction\resources\views/register.blade.php ENDPATH**/ ?>
<h3>User List</h3>
<style>
table, th, td{
        border: 1px solid black;
        border-collapse: collapse;
    }
</style>
<table>
    <thead>
        <th>ID</th>
        <th>Name</th>
        <th>Age</th>
        <th>Phone</th>
        <th>Edit</th>
        <th>Delete</th>
    </thead>
<tbody>
    <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <tr>
    <td><?php echo e($user->id); ?></td>
    <td><?php echo e($user->name); ?></td>
    <td><?php echo e($user->age); ?></td>
    <td><?php echo e($user->phone); ?></td>
    <td><a href="edit/<?php echo e($user->id); ?>">Edit</a></td>
    <td><a href="delete/<?php echo e($user->id); ?>">Delete</a></td>
    </tr>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</tbody>
</table>
<?php /**PATH C:\crudfunction\resources\views/list_user.blade.php ENDPATH**/ ?>
<h3>Edit User Form</h3><br>
<form action="<?php echo e(url('update/'.$user->id)); ?>" method="POST">
    <label for="">Name</label><input type="text" name="name" value="<?php echo e($user->name); ?>"><br>
    <label for="">Age</label><input type="text" name="age" value="<?php echo e($user->age); ?>"><br>
    <label for="">Phone</label><input type="text" name="phone" value="$user->phone}}"><br>
    <input type="submit" value="Update User">
    <?php echo csrf_field(); ?>
</form><?php /**PATH C:\crudfunction\resources\views/edit_user.blade.php ENDPATH**/ ?>